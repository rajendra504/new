import { Component } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user = {
    firstName: '',
    lastName: '',
    email: '',
    gender: '',
    age: 0,
    jobTitle: '',
    experience: 0,
    role: '',
    password:''
  };

 

  register() {
  // Perform client-side validation
  if (this.user.role === 'leader' && this.user.experience < 6) {
    alert("Senior Leader role requires a minimum of 6 years of experience.");
    return;
  } 
  // Perform validation and store user data in the database 
  console.log(this.user);
}

}
