import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  onSubmit(): void {
    // Here, you can implement your authentication logic.
    // Typically, you would send the username and password to a server for validation.
    // For demonstration purposes, we'll log the values to the console.
    console.log('Username:', this.username);
    console.log('Password:', this.password);
  }
}

